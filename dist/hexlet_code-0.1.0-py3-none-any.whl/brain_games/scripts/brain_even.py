#!/usr/bin/env python

from brain_games.logic import construct


def main():
    print('Welcome to the Brain Games!')
    construct()

if __name__ == '__main__':
    main()
